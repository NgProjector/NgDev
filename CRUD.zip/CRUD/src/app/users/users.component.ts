import { Component, OnInit } from '@angular/core';
import { User, UserService } from '../user.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { PaginationService } from '../pagination.service';
@Component({
  selector: 'app-users',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterModule],
  templateUrl: './users.component.html',
  styleUrl: './users.component.css',
})
export class UsersComponent implements OnInit {
  constructor(private userslist: UserService, private route: Router, public paginationService: PaginationService) {}

  list: User[] = [];
  paginatedUserList: User[] = [];
  filteredUserList: User[] = [];
  currentPageInput: number = 1;
  navigateToEdit(id: number): void {
    this.route.navigate(['/users', id, 'edit']);
  }
  navigateToView(id: number): void{
    this.route.navigate(['/users', id, 'view']);
  }
  navigateToCreate() {
    this.route.navigate(['/users/createuser']);
  }

  ngOnInit(): void {
    this.userslist.getUsers().subscribe((res) => {
      this.list = res;
      console.log(this.list)
      this.filteredUserList = res;
      console.log(this.filteredUserList);
      this.paginationService.setTotalItems(this.filteredUserList.length); //10
      this.updatePaginatedProducts();
    });
  }
  updatePaginatedProducts() {
    this.paginatedUserList = this.paginationService.getPaginatedItems(this.filteredUserList) //10 objects
    console.log(this.paginatedUserList)
  }

  onPageChange(page: number) {
    this.paginationService.setPage(page);
    this.updatePaginatedProducts();
    this.currentPageInput = this.paginationService.getCurrentPage(); 
  }
  deleteUser(id: number): void {
    this.userslist.deleteUser(id).subscribe(() => {
      this.list = this.list.filter((d: { id: number }) => d.id !== id);
    });
  }
}
