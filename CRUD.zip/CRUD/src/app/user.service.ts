import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


export interface User{
  id:number; 
  userName:string; 
  password:string
}

@Injectable({
  providedIn: 'root'
})
export class UserService implements User {
// public url="https://dummyjson.com/users";
public url = "https://fakerestapi.azurewebsites.net/api/v1/Users"
  constructor(private http: HttpClient) { }
  id: any;
  userName: any;
  password: any;

  getUsers(): Observable<User[]>{
    return this.http.get<User[]>(this.url);
  }

  getUserById(id:number): Observable<any>{
    return this.http.get<any>(`${this.url}/${id}`);

  }

  updateUser(id: number, user: User): Observable<User>{
    return this.http.put<User>(`${this.url}/${id}`, user);
  }

  deleteUser(id: any){ 
    return this.http.delete<void>(`${this.url}/${id}`);
  }
  createUser(user: User){
    return this.http.post<User>(`${this.url}`, user); 
  }
}
