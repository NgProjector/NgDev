import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PaginationService {

  private itemsPerPage: number = 4;
  private currentPage: number = 1;
  private totalItems: number = 0;

  setItemsPerPage(itemsPerPage: number) {
    this.itemsPerPage = itemsPerPage;
  }

  setTotalItems(total: number) {
    this.totalItems = total
  }

  getCurrentPage() {
    return this.currentPage;
  }

  getTotalPages() {
    return Math.ceil(this.totalItems/this.itemsPerPage);
  }

  setPage(page: number) {
    if (page < 1)
      this.currentPage = 1;
    else if (page > this.getTotalPages())
      this.currentPage = this.getTotalPages();
    else
      this.currentPage = page;

  }

  getPaginatedItems<T>(items: T[]): T[]{
    const firstIteminCurrentPage = (this.currentPage - 1) * this.itemsPerPage;
    const lastIteminCurrentPage = firstIteminCurrentPage + this.itemsPerPage
    const paginatedItems = items.slice(firstIteminCurrentPage, lastIteminCurrentPage);
    
    while (paginatedItems.length < this.itemsPerPage) {
      paginatedItems.push(null as any);
    }
    return paginatedItems;
  }

  constructor() { }
}
