import { Component, OnInit } from '@angular/core';
import { User, UserService } from '../user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-usermodify',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './usermodify.component.html',
  styleUrl: './usermodify.component.css',
})
export class UsermodifyComponent implements OnInit{
  user: User = {
    id: 0,
    userName: '',
    password: '',
  };
  userid:number | any;
  constructor(private userModify: UserService, private router: Router, private route:ActivatedRoute) {}
  ngOnInit(): void {
     this.userid= Number(this.route.snapshot.paramMap.get('id'));
    
    this.userModify.getUserById(this.userid).subscribe((res) =>{
      this.user = res;
    })
  }
  saveUser(user: any) {
    this.userModify.updateUser(this.userid, user).subscribe((res) => {
      // this.router.navigate(['/users'])
      console.log(res);
    });
  }
}
