import { Component } from '@angular/core';
import { UserService } from '../user.service';
import { Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { User } from '../user.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-usercreate',
  standalone: true,
  imports: [RouterModule, FormsModule,CommonModule],
  templateUrl: './usercreate.component.html',
  styleUrl: './usercreate.component.css',
})
export class UsercreateComponent {
[x: string]: any;
  user: User = {
    id: 0,
    userName: '',
    password: '',
  };
  constructor(private usercreate: UserService, private router: Router) {}
  createuser(user: any) {
    console.log('hhiii');

    this.usercreate.createUser(user).subscribe((res) => {
      // this.router.navigate(['/users'])
      console.log(user);
    });
  }
}
