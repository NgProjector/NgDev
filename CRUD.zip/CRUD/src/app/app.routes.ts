import { Routes } from '@angular/router';
import { UsercreateComponent } from './usercreate/usercreate.component';  
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { UsermodifyComponent } from './usermodify/usermodify.component';
import { UsersComponent } from './users/users.component';

export const routes: Routes = [
    { path: '', redirectTo:'users', pathMatch:'full'},
    { path: 'users', component: UsersComponent},
    { path: 'users/createuser', component: UsercreateComponent},
    { path: 'users/:id/view', component: UserdetailsComponent},
    { path: 'users/:id/edit', component: UsermodifyComponent},

];
