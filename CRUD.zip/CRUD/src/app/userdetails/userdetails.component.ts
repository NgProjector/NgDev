import { Component, inject, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../user.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-userdetails',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './userdetails.component.html',
  styleUrl: './userdetails.component.css'
})
export class UserdetailsComponent implements OnInit {

  user: User | null = null;
  constructor(private router:Router, private route:ActivatedRoute,private userService:UserService){}

  ngOnInit(): void {
    const userid= Number(this.route.snapshot.paramMap.get('id'));

    console.log(this.route.snapshot.paramMap.get('id'));
    
    this.userService.getUserById(userid).subscribe((res) =>{
      this.user = res;
    })
  }
  navigateToBack() {
    this.router.navigate(['/users']);
    }
  // userService = inject(UserService);
  
  

}
